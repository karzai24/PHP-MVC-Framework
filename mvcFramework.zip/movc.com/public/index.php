<?php
require_once '../app/bootstrap.php';


// Init Core Lib
 $init = new Core;

?>
