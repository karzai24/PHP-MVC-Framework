
<script type="text/javascript" src="<?php echo URLROOT; ?>/js/movc.js"></script>

</body>
</html>