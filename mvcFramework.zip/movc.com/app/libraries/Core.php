<?php
/*
 *
 * Main App Core ClRL & loads core controller
 * URL FORMAT -conrtoller/method/params
*/

class Core {
	protected $currentController = 'Pages';
	protected $currentMethod = 'index';
	protected $params = [];
	
	public function __construct(){
	//print_r($this->getURL());


	$url = $this->getUrl();

	//Look in controllers for first value
	if(file_exists('../app/controllers/' . ucwords($url[0]) . '.php')){
		// If exists, set as controller
		$this->currentController = ucwords($url[0]);
		// Unset 0 Index
		unset($url[0]);
	}
	//require the controller
	require_once '../app/controllers/' . $this->currentController . '.php';

	//Instantiate controller
	$this->currentController = new $this->currentController; 

	//Check for the second part of URL (Method)

	if(isset($url[1])){
		if(method_exists($this->currentController, $url[1])){
			$this->currentMethod =$url[1];

			//unset index 1
			unset($url[1]);
		}
	}


	//get params
	$this->params = $url ? array_values($url) : [];

	// call a callback with array of parameters
	call_user_func_array([$this->currentController, $this->currentMethod], $this->params);

}	
	public function getUrl(){
	if(isset($_GET['url'])){
		$url = rtrim($_GET['url'], '/');
		$url = filter_var($url, FILTER_SANITIZE_URL);
		$url = explode('/', $url);
		return $url;		
	
	
		}
	}

}

?>
