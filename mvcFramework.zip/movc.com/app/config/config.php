<?php
	//DB Params
	// Make sure to Customize to your Database
	define('DB_HOST', 'localhost');
	define('DB_USER', '__YOUR_USER__');
	define('DB_PASS', '__YOUR_PASS__');
	define('DB_NAME', '__ YOUR_DB_NAME__');

	// App Root
	define('APPROOT', dirname(dirname(__FILE__)));
	// URL Root
	define('URLROOT', 'YOUR_URL');
	// Site Name
	define ('SITENAME', 'YOUR_SITE_NAME');



?>